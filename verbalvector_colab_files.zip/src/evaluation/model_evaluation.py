"""
Model evaluation utilities for VerbalVector.

This module provides utilities for evaluating the performance of the distilled student model
against the teacher model.
"""

import os
import json
import time
import logging
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, List, Optional, Tuple
from sklearn.metrics import mean_squared_error, mean_absolute_error

from src.models.teacher_model import get_teacher_model
from src.models.student_model import StudentModel

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ModelEvaluator:
    """Evaluator for the student model against the teacher model."""
    
    def __init__(
        self, 
        student_model_path: str,
        base_model_name: str = "google/gemma-2b-it",  # Updated to Gemma-2B
        teacher_provider: str = "gemma"  # Default to Gemma
    ):
        """
        Initialize the evaluator.
        
        Args:
            student_model_path: Path to the trained student model
            base_model_name: Base model name for the student model
            teacher_provider: Provider for the teacher model ("anthropic", "openai", or "gemma")
        """
        self.student_model_path = student_model_path
        self.base_model_name = base_model_name
        self.teacher_provider = teacher_provider
        
        # Load student model
        logger.info(f"Loading student model from {student_model_path}")
        self.student_model = StudentModel(model_name=base_model_name, output_dir=student_model_path)
        self.student_model.load_model()
        
        # Get teacher model
        logger.info(f"Initializing teacher model ({teacher_provider})")
        self.teacher_model = get_teacher_model(provider=teacher_provider)
        
        # Initialize metrics tracking
        self.metrics = {}
    
    def evaluate_on_features(self, feature_path: str) -> Dict[str, Any]:
        """
        Evaluate both models on a single feature file.
        
        Args:
            feature_path: Path to feature JSON file
            
        Returns:
            Dictionary with evaluation metrics
        """
        logger.info(f"Evaluating on {feature_path}")
        
        try:
            # Load features
            with open(feature_path, 'r', encoding='utf-8') as f:
                features = json.load(f)
            
            # Generate feedback with teacher model (as ground truth)
            start_time = time.time()
            teacher_feedback = self.teacher_model.generate_feedback(features)
            teacher_time = time.time() - start_time
            
            # Generate feedback with student model
            start_time = time.time()
            student_feedback = self.student_model.generate_feedback(features)
            student_time = time.time() - start_time
            
            # Calculate metrics
            metrics = self._calculate_metrics(teacher_feedback, student_feedback)
            
            # Add timing metrics
            metrics['teacher_inference_time'] = teacher_time
            metrics['student_inference_time'] = student_time
            metrics['speedup'] = teacher_time / student_time if student_time > 0 else float('inf')
            
            logger.info(f"Evaluation complete. Speedup: {metrics['speedup']:.2f}x")
            
            return {
                'feature_path': feature_path,
                'teacher_feedback': teacher_feedback,
                'student_feedback': student_feedback,
                'metrics': metrics
            }
            
        except Exception as e:
            logger.error(f"Error evaluating on {feature_path}: {str(e)}")
            return {
                'feature_path': feature_path,
                'error': str(e)
            }
    
    def _calculate_metrics(self, teacher_feedback: Dict[str, Any], student_feedback: Dict[str, Any]) -> Dict[str, float]:
        """
        Calculate comparison metrics between teacher and student feedback.
        
        Args:
            teacher_feedback: Feedback from teacher model
            student_feedback: Feedback from student model
            
        Returns:
            Dictionary with metrics
        """
        metrics = {}
        
        # Score metrics
        score_metrics = self._evaluate_scores(
            teacher_feedback.get('scores', {}), 
            student_feedback.get('scores', {})
        )
        metrics.update(score_metrics)
        
        # Text similarity metrics
        text_metrics = self._evaluate_text_similarity(
            teacher_feedback, 
            student_feedback
        )
        metrics.update(text_metrics)
        
        # Content overlap metrics
        content_metrics = self._evaluate_content_overlap(
            teacher_feedback, 
            student_feedback
        )
        metrics.update(content_metrics)
        
        return metrics
    
    def _evaluate_scores(self, teacher_scores: Dict[str, float], student_scores: Dict[str, float]) -> Dict[str, float]:
        """
        Evaluate score metrics.
        
        Args:
            teacher_scores: Score dictionary from teacher
            student_scores: Score dictionary from student
            
        Returns:
            Dictionary with score metrics
        """
        metrics = {}
        
        # Collect all scores
        all_teacher_scores = []
        all_student_scores = []
        
        for key in set(teacher_scores.keys()).intersection(student_scores.keys()):
            all_teacher_scores.append(teacher_scores[key])
            all_student_scores.append(student_scores[key])
        
        if all_teacher_scores and all_student_scores:
            # Calculate RMSE
            rmse = np.sqrt(mean_squared_error(all_teacher_scores, all_student_scores))
            metrics['score_rmse'] = rmse
            
            # Calculate MAE
            mae = mean_absolute_error(all_teacher_scores, all_student_scores)
            metrics['score_mae'] = mae
            
            # Calculate how many scores are within +-1 of teacher
            close_scores = sum(abs(t - s) <= 1 for t, s in zip(all_teacher_scores, all_student_scores))
            metrics['score_close_match_rate'] = close_scores / len(all_teacher_scores)
            
            # Calculate exact match rate
            exact_scores = sum(t == s for t, s in zip(all_teacher_scores, all_student_scores))
            metrics['score_exact_match_rate'] = exact_scores / len(all_teacher_scores)
        
        return metrics
    
    def _evaluate_text_similarity(self, teacher_feedback: Dict[str, Any], student_feedback: Dict[str, Any]) -> Dict[str, float]:
        """
        Evaluate text similarity metrics.
        
        Args:
            teacher_feedback: Feedback from teacher model
            student_feedback: Feedback from student model
            
        Returns:
            Dictionary with text similarity metrics
        """
        metrics = {}
        
        # Simple token overlap for assessment
        if 'assessment' in teacher_feedback and 'assessment' in student_feedback:
            teacher_tokens = set(teacher_feedback['assessment'].lower().split())
            student_tokens = set(student_feedback['assessment'].lower().split())
            
            if teacher_tokens and student_tokens:
                overlap = len(teacher_tokens.intersection(student_tokens))
                metrics['assessment_token_overlap'] = overlap / len(teacher_tokens) if teacher_tokens else 0
        
        return metrics
    
    def _evaluate_content_overlap(self, teacher_feedback: Dict[str, Any], student_feedback: Dict[str, Any]) -> Dict[str, float]:
        """
        Evaluate content overlap metrics (strengths and improvements).
        
        Args:
            teacher_feedback: Feedback from teacher model
            student_feedback: Feedback from student model
            
        Returns:
            Dictionary with content overlap metrics
        """
        metrics = {}
        
        # Check if either is missing strengths or improvements
        if not all(k in teacher_feedback for k in ['strengths', 'improvements']) or \
           not all(k in student_feedback for k in ['strengths', 'improvements']):
            return metrics
        
        # Calculate strength similarity
        teacher_strengths = " ".join(teacher_feedback['strengths']).lower()
        student_strengths = " ".join(student_feedback['strengths']).lower()
        
        teacher_strength_tokens = set(teacher_strengths.split())
        student_strength_tokens = set(student_strengths.split())
        
        if teacher_strength_tokens:
            strength_overlap = len(teacher_strength_tokens.intersection(student_strength_tokens))
            metrics['strengths_token_overlap'] = strength_overlap / len(teacher_strength_tokens)
        
        # Calculate improvement similarity
        teacher_improvements = " ".join(teacher_feedback['improvements']).lower()
        student_improvements = " ".join(student_feedback['improvements']).lower()
        
        teacher_improvement_tokens = set(teacher_improvements.split())
        student_improvement_tokens = set(student_improvements.split())
        
        if teacher_improvement_tokens:
            improvement_overlap = len(teacher_improvement_tokens.intersection(student_improvement_tokens))
            metrics['improvements_token_overlap'] = improvement_overlap / len(teacher_improvement_tokens)
        
        # Overall content overlap
        all_teacher_tokens = teacher_strength_tokens.union(teacher_improvement_tokens)
        all_student_tokens = student_strength_tokens.union(student_improvement_tokens)
        
        if all_teacher_tokens:
            content_overlap = len(all_teacher_tokens.intersection(all_student_tokens))
            metrics['overall_content_overlap'] = content_overlap / len(all_teacher_tokens)
        
        return metrics
    
    def evaluate_batch(
        self, 
        feature_files: List[str],
        output_dir: Optional[str] = None,
        save_results: bool = True
    ) -> Dict[str, Any]:
        """
        Evaluate models on multiple feature files.
        
        Args:
            feature_files: List of paths to feature files
            output_dir: Directory to save evaluation results
            save_results: Whether to save results to files
            
        Returns:
            Dictionary with aggregated metrics
        """
        logger.info(f"Evaluating on {len(feature_files)} files")
        
        results = []
        
        for feature_path in feature_files:
            result = self.evaluate_on_features(feature_path)
            results.append(result)
        
        # Aggregate metrics
        aggregated_metrics = self._aggregate_metrics([r['metrics'] for r in results if 'metrics' in r])
        
        # Save results if requested
        if save_results and output_dir:
            os.makedirs(output_dir, exist_ok=True)
            
            # Save detailed results
            results_path = os.path.join(output_dir, "evaluation_results.json")
            with open(results_path, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=2)
            
            # Save aggregated metrics
            metrics_path = os.path.join(output_dir, "aggregated_metrics.json")
            with open(metrics_path, 'w', encoding='utf-8') as f:
                json.dump(aggregated_metrics, f, indent=2)
            
            # Generate plots
            self._generate_evaluation_plots(results, output_dir)
            
            logger.info(f"Saved evaluation results to {output_dir}")
        
        return {
            'results': results,
            'aggregated_metrics': aggregated_metrics
        }
    
    def _aggregate_metrics(self, metrics_list: List[Dict[str, float]]) -> Dict[str, float]:
        """
        Aggregate metrics from individual evaluations.
        
        Args:
            metrics_list: List of metric dictionaries
            
        Returns:
            Dictionary with aggregated metrics
        """
        if not metrics_list:
            return {}
        
        aggregated = {}
        
        # Get all metric keys
        all_keys = set()
        for metrics in metrics_list:
            all_keys.update(metrics.keys())
        
        # Calculate mean for each metric
        for key in all_keys:
            values = [m[key] for m in metrics_list if key in m]
            if values:
                aggregated[f"mean_{key}"] = np.mean(values)
                aggregated[f"std_{key}"] = np.std(values)
                aggregated[f"min_{key}"] = np.min(values)
                aggregated[f"max_{key}"] = np.max(values)
        
        return aggregated
    
    def _generate_evaluation_plots(self, results: List[Dict[str, Any]], output_dir: str) -> None:
        """
        Generate evaluation plots.
        
        Args:
            results: List of evaluation results
            output_dir: Directory to save plots
        """
        try:
            # Create plots directory
            plots_dir = os.path.join(output_dir, "plots")
            os.makedirs(plots_dir, exist_ok=True)
            
            # Extract metrics
            metrics_list = [r['metrics'] for r in results if 'metrics' in r]
            
            # Plot speedup
            speedups = [m['speedup'] for m in metrics_list if 'speedup' in m]
            if speedups:
                plt.figure(figsize=(10, 6))
                plt.hist(speedups, bins=10)
                plt.xlabel('Speedup Factor')
                plt.ylabel('Frequency')
                plt.title('Student Model Speedup Distribution')
                plt.savefig(os.path.join(plots_dir, "speedup_distribution.png"))
                plt.close()
            
            # Plot score RMSE
            score_rmse = [m['score_rmse'] for m in metrics_list if 'score_rmse' in m]
            if score_rmse:
                plt.figure(figsize=(10, 6))
                plt.hist(score_rmse, bins=10)
                plt.xlabel('Score RMSE')
                plt.ylabel('Frequency')
                plt.title('Score RMSE Distribution')
                plt.savefig(os.path.join(plots_dir, "score_rmse_distribution.png"))
                plt.close()
            
            # Plot content overlap
            content_overlap = [m['overall_content_overlap'] for m in metrics_list if 'overall_content_overlap' in m]
            if content_overlap:
                plt.figure(figsize=(10, 6))
                plt.hist(content_overlap, bins=10)
                plt.xlabel('Content Overlap Ratio')
                plt.ylabel('Frequency')
                plt.title('Content Overlap Distribution')
                plt.savefig(os.path.join(plots_dir, "content_overlap_distribution.png"))
                plt.close()
            
        except Exception as e:
            logger.error(f"Error generating evaluation plots: {str(e)}")


def evaluate_model(
    student_model_path: str,
    feature_dir: str,
    output_dir: str = "evaluation_results",
    base_model_name: str = "google/gemma-2b-it",  # Updated to Gemma-2B
    teacher_provider: str = "gemma",  # Default to Gemma
    num_samples: Optional[int] = None
) -> Dict[str, Any]:
    """
    Evaluate the student model against the teacher model.
    
    Args:
        student_model_path: Path to the trained student model
        feature_dir: Directory with feature files
        output_dir: Directory to save evaluation results
        base_model_name: Base model name for the student model
        teacher_provider: Provider for the teacher model
        num_samples: Optional number of samples to evaluate (if None, use all)
        
    Returns:
        Dictionary with evaluation results
    """
    # Validate inputs
    if not os.path.exists(student_model_path):
        raise ValueError(f"Student model path does not exist: {student_model_path}")
    
    if not os.path.exists(feature_dir):
        raise ValueError(f"Feature directory does not exist: {feature_dir}")
    
    # Get feature files
    feature_files = [os.path.join(feature_dir, f) for f in os.listdir(feature_dir) 
                    if f.endswith("_features.json")]
    
    if not feature_files:
        raise ValueError(f"No feature files found in {feature_dir}")
    
    # Sample if requested
    if num_samples is not None and num_samples < len(feature_files):
        np.random.shuffle(feature_files)
        feature_files = feature_files[:num_samples]
    
    # Initialize evaluator
    evaluator = ModelEvaluator(
        student_model_path=student_model_path,
        base_model_name=base_model_name,
        teacher_provider=teacher_provider
    )
    
    # Run evaluation
    results = evaluator.evaluate_batch(
        feature_files=feature_files,
        output_dir=output_dir,
        save_results=True
    )
    
    # Print summary
    aggregated = results['aggregated_metrics']
    print("\nEvaluation Summary:")
    print(f"Evaluated on {len(feature_files)} samples")
    print(f"Score RMSE: {aggregated.get('mean_score_rmse', 'N/A'):.2f}")
    print(f"Close match rate: {aggregated.get('mean_score_close_match_rate', 'N/A'):.2%}")
    print(f"Text similarity: {aggregated.get('mean_assessment_token_overlap', 'N/A'):.2%}")
    print(f"Average speedup: {aggregated.get('mean_speedup', 'N/A'):.2f}x")
    
    return results


if __name__ == "__main__":
    # Example usage
    student_model_path = "models/distilled_feedback"
    feature_dir = "data/processed"
    
    if os.path.exists(student_model_path) and os.path.exists(feature_dir):
        evaluate_model(
            student_model_path=student_model_path,
            feature_dir=feature_dir
        )
    else:
        print("Student model or feature directory not found.")
        print("Please train the student model and process presentations first.") 