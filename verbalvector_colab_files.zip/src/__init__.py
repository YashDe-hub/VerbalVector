"""
VerbalVector: Model Distillation for Presentation Feedback
""" 