"""
Data collection utilities for VerbalVector.

This module provides functionality to collect TED talk data for training the presentation feedback model.
"""

import os
import logging
from typing import List, Dict, Optional
import requests
from pydub import AudioSegment
import yt_dlp

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TEDTalkCollector:
    """Class for collecting TED talk data."""
    
    def __init__(self, output_dir: str = "data/raw"):
        """
        Initialize the TED talk collector.
        
        Args:
            output_dir: Directory to save downloaded content
        """
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, "audio"), exist_ok=True)
        os.makedirs(os.path.join(output_dir, "transcripts"), exist_ok=True)
        
    def download_talk(self, video_url: str, output_filename: Optional[str] = None) -> Dict[str, str]:
        """
        Download a TED talk video and extract audio.
        
        Args:
            video_url: URL of the TED talk video
            output_filename: Base filename to use for saved files (without extension)
            
        Returns:
            Dictionary with paths to downloaded files
        """
        logger.info(f"Downloading TED talk: {video_url}")
        
        # Use yt-dlp to download video
        ydl_opts = {
            'format': 'bestaudio/best',
            'outtmpl': os.path.join(self.output_dir, 'tmp_%(title)s.%(ext)s'),
            'writesubtitles': True,
            'writeautomaticsub': True,
            'subtitleslangs': ['en'],
            'skip_download': False,
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'wav',
                'preferredquality': '192',
            }],
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(video_url, download=True)
            title = info_dict.get('title', 'unknown_title').replace(' ', '_')
            
            if output_filename is None:
                output_filename = title
                
            # Get downloaded files
            audio_path = os.path.join(self.output_dir, f"tmp_{title}.wav")
            subtitle_path = os.path.join(self.output_dir, f"tmp_{title}.en.vtt")
            
            # Move files to final locations
            final_audio_path = os.path.join(self.output_dir, "audio", f"{output_filename}.wav")
            final_transcript_path = os.path.join(self.output_dir, "transcripts", f"{output_filename}.txt")
            
            # Convert audio if needed
            audio = AudioSegment.from_wav(audio_path)
            audio.export(final_audio_path, format="wav")
            
            # Convert subtitles to plain text
            transcript = self._convert_vtt_to_text(subtitle_path)
            with open(final_transcript_path, 'w', encoding='utf-8') as f:
                f.write(transcript)
                
            # Clean up temporary files
            os.remove(audio_path)
            os.remove(subtitle_path)
            
            return {
                'audio_path': final_audio_path,
                'transcript_path': final_transcript_path,
                'title': title
            }
    
    def download_multiple_talks(self, video_urls: List[str]) -> List[Dict[str, str]]:
        """
        Download multiple TED talks.
        
        Args:
            video_urls: List of TED talk URLs
            
        Returns:
            List of dictionaries with paths to downloaded files
        """
        results = []
        for url in video_urls:
            try:
                result = self.download_talk(url)
                results.append(result)
            except Exception as e:
                logger.error(f"Error downloading {url}: {str(e)}")
        
        return results
    
    def _convert_vtt_to_text(self, vtt_path: str) -> str:
        """
        Convert VTT subtitle file to plain text.
        
        Args:
            vtt_path: Path to VTT file
            
        Returns:
            Plain text transcript
        """
        with open(vtt_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Skip header and timing information
        text_lines = []
        for line in lines:
            line = line.strip()
            if (line and not line.startswith('WEBVTT') and 
                not line.startswith('NOTE') and 
                not '-->' in line and 
                not line.isdigit()):
                text_lines.append(line)
        
        return ' '.join(text_lines)


def get_ted_talk_urls(num_talks: int = 10, category: str = "technology") -> List[str]:
    """
    Get URLs for popular TED talks.
    
    Args:
        num_talks: Number of talks to retrieve
        category: Category of talks to retrieve
        
    Returns:
        List of TED talk URLs
    """
    # For the PoC, we could hardcode a few high-quality TED talk URLs
    # In a real implementation, this would scrape TED.com or use an API
    
    sample_urls = [
        "https://www.youtube.com/watch?v=8S0FDjFBj8o",  # The power of vulnerability | Brené Brown
        "https://www.youtube.com/watch?v=iCvmsMzlF7o",  # How great leaders inspire action | Simon Sinek
        "https://www.youtube.com/watch?v=H14bBuluwB8",  # Your body language may shape who you are | Amy Cuddy
        "https://www.youtube.com/watch?v=Unzc731iCUY",  # How to speak so that people want to listen | Julian Treasure
        "https://www.youtube.com/watch?v=qp0HIF3SfI4",  # The skill of self confidence | Dr. Ivan Joseph
    ]
    
    return sample_urls[:min(num_talks, len(sample_urls))]


if __name__ == "__main__":
    # Example usage
    collector = TEDTalkCollector()
    urls = get_ted_talk_urls(num_talks=2)
    results = collector.download_multiple_talks(urls)
    
    for result in results:
        print(f"Downloaded: {result['title']}")
        print(f"  Audio: {result['audio_path']}")
        print(f"  Transcript: {result['transcript_path']}") 