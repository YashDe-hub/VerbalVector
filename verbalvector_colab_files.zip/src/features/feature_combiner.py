"""
Feature combination for VerbalVector.

This module combines audio and text features into a unified feature set for analysis.
"""

import os
import json
import logging
from typing import Dict, Any, Optional, List, Tuple

from src.features.audio_features import process_presentation
from src.features.text_features import process_transcript

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class FeatureCombiner:
    """Class for combining audio and text features."""
    
    def __init__(self):
        """Initialize the feature combiner."""
        pass
    
    def combine_features(self, audio_path: str, transcript_path: str) -> Dict[str, Any]:
        """
        Combine audio and text features from a presentation.
        
        Args:
            audio_path: Path to the audio file
            transcript_path: Path to the transcript file
            
        Returns:
            Dictionary of combined features
        """
        logger.info(f"Extracting features from {audio_path} and {transcript_path}")
        
        # Extract audio features
        audio_features = process_presentation(audio_path)
        
        # Extract text features
        text_features = process_transcript(transcript_path)
        
        # Combine features
        combined_features = self._merge_feature_dicts(
            audio_features=audio_features,
            text_features=text_features
        )
        
        # Add derived/cross-modal features
        derived_features = self._derive_cross_modal_features(
            audio_features=audio_features,
            text_features=text_features
        )
        
        combined_features.update(derived_features)
        
        # Add metadata
        combined_features['metadata'] = {
            'audio_path': audio_path,
            'transcript_path': transcript_path
        }
        
        return combined_features
    
    def _merge_feature_dicts(self, audio_features: Dict[str, Any], text_features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Merge audio and text feature dictionaries with prefixes to avoid key collisions.
        
        Args:
            audio_features: Dictionary of audio features
            text_features: Dictionary of text features
            
        Returns:
            Merged dictionary
        """
        merged = {}
        
        # Add audio features with prefix
        for key, value in audio_features.items():
            merged[f"audio_{key}"] = value
            
        # Add text features with prefix
        for key, value in text_features.items():
            merged[f"text_{key}"] = value
            
        return merged
    
    def _derive_cross_modal_features(self, audio_features: Dict[str, Any], text_features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Derive new features that combine information from both audio and text.
        
        Args:
            audio_features: Dictionary of audio features
            text_features: Dictionary of text features
            
        Returns:
            Dictionary of derived features
        """
        derived = {}
        
        # Calculate speech rate in words per minute
        if 'duration' in audio_features and 'word_count' in text_features:
            duration_minutes = audio_features['duration'] / 60.0
            wpm = text_features['word_count'] / max(0.01, duration_minutes)
            derived['words_per_minute'] = float(wpm)
        
        # Calculate filler word frequency (fillers per minute)
        if 'duration' in audio_features and 'total_filler_words' in text_features:
            duration_minutes = audio_features['duration'] / 60.0
            fillers_per_minute = text_features['total_filler_words'] / max(0.01, duration_minutes)
            derived['fillers_per_minute'] = float(fillers_per_minute)
        
        # Calculate pause-to-speech ratio
        if 'total_pause_duration' in audio_features and 'duration' in audio_features:
            speech_duration = audio_features['duration'] - audio_features['total_pause_duration']
            if speech_duration > 0:
                pause_to_speech_ratio = audio_features['total_pause_duration'] / speech_duration
                derived['pause_to_speech_ratio'] = float(pause_to_speech_ratio)
        
        # Calculate vocal expressiveness score (combination of pitch variation and volume variation)
        if 'pitch_std' in audio_features and 'volume_std' in audio_features:
            # Normalize by typical values
            normalized_pitch_var = min(1.0, audio_features['pitch_std'] / 50.0)  # Typical std is ~30-70 Hz
            normalized_volume_var = min(1.0, audio_features['volume_std'] / 0.1)  # Typical std is ~0.05-0.15
            
            expressiveness = (normalized_pitch_var + normalized_volume_var) / 2.0
            derived['vocal_expressiveness'] = float(expressiveness)
        
        # Calculate speech clarity score (combination of speech rate and complex words)
        if 'speech_rate' in audio_features and 'complex_word_percentage' in text_features:
            # Optimal speech rate is around 150-160 words per minute
            if 'words_per_minute' in derived:
                rate_factor = 1.0 - min(1.0, abs(derived['words_per_minute'] - 155) / 50.0)
            else:
                rate_factor = 0.5  # Default if we can't calculate WPM
                
            # Excessive complex words reduce clarity
            complexity_factor = 1.0 - min(1.0, text_features['complex_word_percentage'] / 25.0)
            
            clarity = (rate_factor + complexity_factor) / 2.0
            derived['speech_clarity'] = float(clarity)
            
        return derived


def process_presentation_data(
    audio_path: str, 
    transcript_path: str, 
    output_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Process presentation data and extract combined features.
    
    Args:
        audio_path: Path to audio file
        transcript_path: Path to transcript file
        output_path: Optional path to save features as JSON
        
    Returns:
        Dictionary of combined features
    """
    combiner = FeatureCombiner()
    features = combiner.combine_features(audio_path, transcript_path)
    
    # Save to file if output path is provided
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(features, f, indent=2)
        logger.info(f"Saved combined features to {output_path}")
    
    return features


def batch_process_presentations(
    presentation_data: List[Dict[str, str]], 
    output_dir: str = "data/processed"
) -> List[Dict[str, Any]]:
    """
    Process multiple presentations.
    
    Args:
        presentation_data: List of dictionaries with audio_path and transcript_path
        output_dir: Directory to save feature files
        
    Returns:
        List of dictionaries with combined features
    """
    os.makedirs(output_dir, exist_ok=True)
    results = []
    
    for i, data in enumerate(presentation_data):
        try:
            audio_path = data['audio_path']
            transcript_path = data['transcript_path']
            
            # Generate output filename
            filename = os.path.basename(audio_path).split('.')[0]
            output_path = os.path.join(output_dir, f"{filename}_features.json")
            
            # Process presentation
            features = process_presentation_data(
                audio_path=audio_path,
                transcript_path=transcript_path,
                output_path=output_path
            )
            
            # Store result
            results.append({
                'input': data,
                'output_path': output_path,
                'features': features
            })
            
            logger.info(f"Processed presentation {i+1}/{len(presentation_data)}: {filename}")
            
        except Exception as e:
            logger.error(f"Error processing presentation {i+1}/{len(presentation_data)}: {str(e)}")
    
    return results


if __name__ == "__main__":
    # Example usage
    test_data = [
        {
            'audio_path': "data/raw/audio/sample_presentation.wav",
            'transcript_path': "data/raw/transcripts/sample_presentation.txt"
        }
    ]
    
    if (os.path.exists(test_data[0]['audio_path']) and 
        os.path.exists(test_data[0]['transcript_path'])):
        
        results = batch_process_presentations(test_data)
        print(f"Processed {len(results)} presentations")
        
    else:
        print("Test files not found. Please download presentation data first.") 