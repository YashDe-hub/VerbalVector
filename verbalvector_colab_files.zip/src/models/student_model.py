"""
Student model for VerbalVector.

This module implements the student model that is distilled from the teacher model
to provide efficient, local inference for presentation feedback.
"""

import os
import json
import logging
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM,  # Changed from Seq2SeqLM to CausalLM for Gemma
    Trainer,  # Standard Trainer instead of Seq2SeqTrainer
    TrainingArguments,  # Standard TrainingArguments
    DataCollatorForLanguageModeling  # For causal language modeling
)
from typing import Dict, Any, List, Tuple, Optional
from tqdm import tqdm

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class PresentationFeedbackDataset(Dataset):
    """Dataset for presentation feedback distillation."""
    
    def __init__(self, data_files: List[Dict[str, str]], tokenizer, max_length: int = 512):
        """
        Initialize dataset.
        
        Args:
            data_files: List of dictionaries with feature_path and feedback_path
            tokenizer: Tokenizer for the model
            max_length: Maximum sequence length
        """
        self.data = []
        self.tokenizer = tokenizer
        self.max_length = max_length
        
        # Load data
        for item in data_files:
            try:
                # Load features
                with open(item['feature_path'], 'r', encoding='utf-8') as f:
                    features = json.load(f)
                
                # Load feedback
                with open(item['feedback_path'], 'r', encoding='utf-8') as f:
                    feedback = json.load(f)
                
                # Format inputs and outputs
                input_text = self._format_features_as_text(features)
                output_text = self._format_feedback_as_text(feedback)
                
                # Add to dataset
                self.data.append({
                    'input': input_text,
                    'output': output_text,
                    'feature_path': item['feature_path'],
                    'feedback_path': item['feedback_path']
                })
                
            except Exception as e:
                logger.error(f"Error loading data file: {str(e)}")
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        
        # Tokenize input
        input_encoding = self.tokenizer(
            item['input'],
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        # Tokenize output
        output_encoding = self.tokenizer(
            item['output'],
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        # Format for seq2seq
        return {
            'input_ids': input_encoding.input_ids.squeeze(),
            'attention_mask': input_encoding.attention_mask.squeeze(),
            'labels': output_encoding.input_ids.squeeze()
        }
    
    def _format_features_as_text(self, features: Dict[str, Any]) -> str:
        """
        Format presentation features as text for model input.
        
        Args:
            features: Feature dictionary
            
        Returns:
            Formatted input text
        """
        # Header
        text = "Analyze this presentation based on the following metrics:\n\n"
        
        # Format key features
        if 'audio_duration' in features:
            text += f"Duration: {features['audio_duration']:.2f} seconds\n"
        
        if 'words_per_minute' in features:
            text += f"Speech rate: {features['words_per_minute']:.1f} words per minute\n"
        
        if 'audio_pitch_mean' in features and 'audio_pitch_std' in features:
            text += f"Pitch: mean {features['audio_pitch_mean']:.1f} Hz, variation {features['audio_pitch_std']:.1f} Hz\n"
        
        if 'audio_volume_mean' in features and 'audio_volume_std' in features:
            text += f"Volume: mean {features['audio_volume_mean']:.3f}, variation {features['audio_volume_std']:.3f}\n"
        
        if 'audio_num_pauses' in features and 'audio_mean_pause_duration' in features:
            text += f"Pauses: {features['audio_num_pauses']} pauses, avg duration {features['audio_mean_pause_duration']:.2f} seconds\n"
        
        if 'text_word_count' in features and 'text_sentence_count' in features:
            text += f"Content: {features['text_word_count']} words, {features['text_sentence_count']} sentences\n"
        
        if 'text_filler_word_rate' in features:
            text += f"Filler words: {features['text_filler_word_rate']:.1f}% of words\n"
        
        if 'fillers_per_minute' in features:
            text += f"Filler frequency: {features['fillers_per_minute']:.1f} fillers per minute\n"
        
        if 'text_lexical_diversity' in features:
            text += f"Vocabulary diversity: {features['text_lexical_diversity']:.3f}\n"
        
        if 'text_flesch_kincaid_grade' in features:
            text += f"Reading level: grade {features['text_flesch_kincaid_grade']:.1f}\n"
        
        if 'vocal_expressiveness' in features:
            text += f"Vocal expressiveness: {features['vocal_expressiveness']:.2f} (0-1 scale)\n"
        
        if 'speech_clarity' in features:
            text += f"Speech clarity: {features['speech_clarity']:.2f} (0-1 scale)\n"
        
        # Add instruction
        text += "\nProvide feedback on this presentation with scores, strengths, areas for improvement, and an overall assessment."
        
        return text
    
    def _format_feedback_as_text(self, feedback: Dict[str, Any]) -> str:
        """
        Format feedback as text for model output.
        
        Args:
            feedback: Feedback dictionary from teacher model
            
        Returns:
            Formatted output text
        """
        text = "FEEDBACK:\n\n"
        
        # Scores
        text += "SCORES (1-10):\n"
        for category, score in feedback['scores'].items():
            text += f"- {category.capitalize()}: {score}/10\n"
        
        # Strengths
        text += "\nSTRENGTHS:\n"
        for i, strength in enumerate(feedback['strengths']):
            text += f"{i+1}. {strength}\n"
        
        # Improvements
        text += "\nAREAS FOR IMPROVEMENT:\n"
        for i, improvement in enumerate(feedback['improvements']):
            text += f"{i+1}. {improvement}\n"
        
        # Assessment
        text += f"\nOVERALL ASSESSMENT:\n{feedback['assessment']}"
        
        return text


class StudentModel:
    """Student model for presentation feedback distillation using Gemma-2B."""
    
    def __init__(
        self, 
        model_name: str = "google/gemma-2b-it", 
        output_dir: str = "models/distilled_feedback"
    ):
        """
        Initialize the student model.
        
        Args:
            model_name: Base model to use for distillation (default: Gemma-2B)
            output_dir: Directory to save model outputs
        """
        self.model_name = model_name
        self.output_dir = output_dir
        self.tokenizer = None
        self.model = None
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
    
    def load_model(self):
        """Load the model and tokenizer."""
        logger.info(f"Loading model: {self.model_name}")
        
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForCausalLM.from_pretrained(self.model_name)
        
        # Add padding token if it doesn't exist
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            self.model.config.pad_token_id = self.model.config.eos_token_id
    
    def train(
        self,
        train_files: List[Dict[str, str]],
        eval_files: Optional[List[Dict[str, str]]] = None,
        batch_size: int = 2,  # Smaller batch size for Gemma-2B
        epochs: int = 5,
        learning_rate: float = 1e-5,  # Lower learning rate for fine-tuning
        warmup_steps: int = 100,
        gradient_accumulation_steps: int = 4,  # Increase for stability
        fp16: bool = True
    ):
        """
        Train the student model on teacher-generated feedback.
        
        Args:
            train_files: List of dictionaries with feature_path and feedback_path for training
            eval_files: Optional list of dictionaries for evaluation
            batch_size: Batch size for training
            epochs: Number of training epochs
            learning_rate: Learning rate
            warmup_steps: Warmup steps for scheduler
            gradient_accumulation_steps: Gradient accumulation steps
            fp16: Whether to use mixed precision training
        """
        logger.info(f"Training student model with {len(train_files)} examples")
        
        # Load model if not already loaded
        if self.tokenizer is None or self.model is None:
            self.load_model()
        
        # Prepare datasets
        train_dataset = PresentationFeedbackDataset(train_files, self.tokenizer)
        
        eval_dataset = None
        if eval_files:
            eval_dataset = PresentationFeedbackDataset(eval_files, self.tokenizer)
        
        # Data collator
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False  # We're doing causal LM, not masked LM
        )
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=self.output_dir,
            overwrite_output_dir=True,
            per_device_train_batch_size=batch_size,
            per_device_eval_batch_size=batch_size,
            eval_accumulation_steps=4,
            learning_rate=learning_rate,
            num_train_epochs=epochs,
            weight_decay=0.01,
            gradient_accumulation_steps=gradient_accumulation_steps,
            save_total_limit=3,
            save_strategy="epoch",
            evaluation_strategy="epoch" if eval_dataset else "no",
            logging_dir=os.path.join(self.output_dir, "logs"),
            logging_steps=10,
            fp16=fp16,
            fp16_full_eval=fp16,
            warmup_steps=warmup_steps,
            load_best_model_at_end=True if eval_dataset else False,
            seed=42
        )
        
        # Initialize trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            tokenizer=self.tokenizer,
            data_collator=data_collator,
        )
        
        # Train model
        logger.info("Starting training...")
        train_result = trainer.train()
        
        # Save model
        logger.info("Saving model...")
        trainer.save_model()
        self.tokenizer.save_pretrained(self.output_dir)
        
        # Save training metrics
        metrics = train_result.metrics
        trainer.log_metrics("train", metrics)
        trainer.save_metrics("train", metrics)
        
        # Save hyperparameters
        trainer.save_state()
        
        logger.info("Training complete")
    
    def optimize_for_inference(self, quantize: bool = True):
        """
        Optimize the model for inference.
        
        Args:
            quantize: Whether to quantize the model
        """
        logger.info("Optimizing model for inference")
        
        # Load model if not already loaded
        if self.model is None:
            self.load_model()
        
        # Quantize with bitsandbytes if requested
        if quantize:
            try:
                import bitsandbytes as bnb
                
                # Save 8-bit quantized model
                quantized_dir = os.path.join(self.output_dir, "quantized")
                os.makedirs(quantized_dir, exist_ok=True)
                
                logger.info(f"Quantizing model to 4-bit and saving to {quantized_dir}")
                
                # Save 4-bit quantized model
                from transformers import BitsAndBytesConfig
                
                # Configure 4-bit quantization
                quantization_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=torch.float16,
                    bnb_4bit_quant_type="nf4"
                )
                
                # Load and save in 4-bit quantized format
                model_4bit = AutoModelForCausalLM.from_pretrained(
                    self.output_dir,
                    quantization_config=quantization_config
                )
                
                # Save quantized model
                model_4bit.save_pretrained(quantized_dir)
                self.tokenizer.save_pretrained(quantized_dir)
                
                logger.info("Quantization complete")
                
            except Exception as e:
                logger.error(f"Error quantizing model: {str(e)}")
    
    def generate_feedback(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate feedback using the student model.
        
        Args:
            features: Dictionary of presentation features
            
        Returns:
            Dictionary with feedback
        """
        logger.info("Generating feedback with student model")
        
        # Load model if not already loaded
        if self.tokenizer is None or self.model is None:
            self.load_model()
        
        # Format input
        dataset = PresentationFeedbackDataset([{'feature_path': '', 'feedback_path': ''}], self.tokenizer)
        input_text = dataset._format_features_as_text(features)
        
        # Tokenize input
        inputs = self.tokenizer(
            input_text, 
            return_tensors="pt", 
            max_length=512, 
            truncation=True
        )
        
        # Generate output
        with torch.no_grad():
            outputs = self.model.generate(
                input_ids=inputs.input_ids,
                attention_mask=inputs.attention_mask,
                max_length=1024,  # Longer outputs for Gemma
                do_sample=True,
                temperature=0.3,
                top_p=0.95,
                repetition_penalty=1.2
            )
        
        # Decode output
        feedback_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Parse feedback into dictionary format
        feedback = self._parse_feedback_text(feedback_text)
        
        return feedback
    
    def _parse_feedback_text(self, text: str) -> Dict[str, Any]:
        """
        Parse generated text into structured feedback.
        
        Args:
            text: Generated feedback text
            
        Returns:
            Dictionary with structured feedback
        """
        feedback = {
            "scores": {},
            "strengths": [],
            "improvements": [],
            "assessment": ""
        }
        
        # Parse scores
        scores_section = text.split("SCORES (1-10):", 1)[-1].split("STRENGTHS:", 1)[0].strip()
        score_lines = scores_section.split("\n")
        
        for line in score_lines:
            if ":" in line:
                category, score_text = line.split(":", 1)
                category = category.strip().lower().replace("-", "").replace(" ", "")
                
                if category.startswith("-"):
                    category = category[1:].strip()
                
                # Extract score value
                score_value = None
                for part in score_text.split():
                    if "/" in part:
                        try:
                            score_value = int(part.split("/")[0])
                            break
                        except ValueError:
                            pass
                
                if score_value is not None:
                    feedback["scores"][category] = score_value
        
        # Parse strengths
        strengths_section = text.split("STRENGTHS:", 1)[-1].split("AREAS FOR IMPROVEMENT:", 1)[0].strip()
        strengths_lines = strengths_section.split("\n")
        
        for line in strengths_lines:
            # Skip empty lines
            if line.strip():
                # Remove numbering if present
                strength = line
                if ". " in line[:4]:  # Check if line starts with a number
                    strength = line.split(". ", 1)[1]
                feedback["strengths"].append(strength.strip())
        
        # Parse improvements
        improvements_section = text.split("AREAS FOR IMPROVEMENT:", 1)[-1].split("OVERALL ASSESSMENT:", 1)[0].strip()
        improvements_lines = improvements_section.split("\n")
        
        for line in improvements_lines:
            # Skip empty lines
            if line.strip():
                # Remove numbering if present
                improvement = line
                if ". " in line[:4]:  # Check if line starts with a number
                    improvement = line.split(". ", 1)[1]
                feedback["improvements"].append(improvement.strip())
        
        # Parse assessment
        if "OVERALL ASSESSMENT:" in text:
            feedback["assessment"] = text.split("OVERALL ASSESSMENT:", 1)[1].strip()
        
        return feedback


def prepare_training_data(
    feature_dir: str = "data/processed", 
    feedback_dir: str = "data/feedback"
) -> List[Dict[str, str]]:
    """
    Prepare training data from features and feedback.
    
    Args:
        feature_dir: Directory with feature files
        feedback_dir: Directory with feedback files
        
    Returns:
        List of dictionaries with feature_path and feedback_path
    """
    training_data = []
    
    # Get all feature files
    feature_files = [f for f in os.listdir(feature_dir) if f.endswith("_features.json")]
    
    for feature_file in feature_files:
        # Derive expected feedback filename
        base_name = feature_file.replace("_features.json", "")
        feedback_file = f"{base_name}_feedback.json"
        
        # Check if feedback file exists
        feedback_path = os.path.join(feedback_dir, feedback_file)
        if os.path.exists(feedback_path):
            training_data.append({
                "feature_path": os.path.join(feature_dir, feature_file),
                "feedback_path": feedback_path
            })
    
    return training_data


def train_student_model(
    feature_dir: str = "data/processed",
    feedback_dir: str = "data/feedback",
    model_name: str = "google/gemma-2b-it",  # Updated default model
    output_dir: str = "models/distilled_feedback",
    eval_split: float = 0.2,
    epochs: int = 5  # Reduced default epochs
):
    """
    Train a student model using distillation.
    
    Args:
        feature_dir: Directory with feature files
        feedback_dir: Directory with feedback files
        model_name: Base model to use (default: Gemma-2B)
        output_dir: Directory to save model
        eval_split: Fraction of data to use for evaluation
        epochs: Number of training epochs
    """
    # Prepare training data
    data = prepare_training_data(feature_dir, feedback_dir)
    
    if len(data) == 0:
        logger.error("No training data found. Please generate features and feedback first.")
        return
    
    logger.info(f"Found {len(data)} training examples")
    
    # Split into train and eval
    np.random.shuffle(data)
    split_idx = max(1, int(len(data) * (1 - eval_split)))
    
    train_data = data[:split_idx]
    eval_data = data[split_idx:] if eval_split > 0 else None
    
    logger.info(f"Training on {len(train_data)} examples, evaluating on {len(eval_data) if eval_data else 0} examples")
    
    # Initialize student model
    student = StudentModel(model_name=model_name, output_dir=output_dir)
    
    # Train model
    student.train(
        train_files=train_data,
        eval_files=eval_data,
        epochs=epochs,
        batch_size=2  # Small batch size for limited data
    )
    
    # Optimize for inference
    student.optimize_for_inference()
    
    logger.info(f"Student model training complete. Model saved to {output_dir}")


if __name__ == "__main__":
    # Example usage
    feature_dir = "data/processed"
    feedback_dir = "data/feedback"
    
    if os.path.exists(feature_dir) and os.path.exists(feedback_dir):
        train_student_model(
            feature_dir=feature_dir,
            feedback_dir=feedback_dir,
            epochs=5  # Reduced for example
        )
    else:
        print("Feature or feedback directories not found.")
        print("Please process presentations and generate teacher feedback first.") 