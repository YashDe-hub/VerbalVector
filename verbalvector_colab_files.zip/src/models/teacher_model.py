"""
Teacher model for VerbalVector.

This module implements a large language model-based 'teacher' that generates expert-level feedback
on presentations based on extracted features.
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
import time

# Import LLM APIs
from anthropic import Anthropic
from openai import OpenAI
import google.generativeai as genai  # For Gemma API

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class TeacherLLM:
    """Base class for LLM-based teacher models."""
    
    def __init__(self, model_name: str = None):
        """
        Initialize the teacher model.
        
        Args:
            model_name: Name/identifier of the LLM to use
        """
        self.model_name = model_name
    
    def generate_feedback(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate expert feedback based on presentation features.
        
        Args:
            features: Dictionary of presentation features
            
        Returns:
            Dictionary with structured feedback
        """
        raise NotImplementedError("Subclasses must implement generate_feedback")
    
    def _format_feature_input(self, features: Dict[str, Any]) -> str:
        """
        Format features into a string for the LLM prompt.
        
        Args:
            features: Dictionary of presentation features
            
        Returns:
            Formatted string for LLM prompt
        """
        # Extract key metrics that are most relevant to presentations
        feature_text = "PRESENTATION FEATURES:\n\n"
        
        # Duration
        if 'audio_duration' in features:
            feature_text += f"- Duration: {features['audio_duration']:.2f} seconds\n"
        
        # Speech rate
        if 'words_per_minute' in features:
            feature_text += f"- Speech rate: {features['words_per_minute']:.1f} words per minute\n"
        
        # Pitch stats
        if 'audio_pitch_mean' in features and 'audio_pitch_std' in features:
            feature_text += f"- Pitch: mean {features['audio_pitch_mean']:.1f} Hz, variation {features['audio_pitch_std']:.1f} Hz\n"
        
        # Volume stats
        if 'audio_volume_mean' in features and 'audio_volume_std' in features:
            feature_text += f"- Volume: mean {features['audio_volume_mean']:.3f}, variation {features['audio_volume_std']:.3f}\n"
        
        # Pause metrics
        if 'audio_num_pauses' in features and 'audio_mean_pause_duration' in features:
            feature_text += f"- Pauses: {features['audio_num_pauses']} pauses, avg duration {features['audio_mean_pause_duration']:.2f} seconds\n"
        
        # Text metrics
        if 'text_word_count' in features and 'text_sentence_count' in features:
            feature_text += f"- Content: {features['text_word_count']} words, {features['text_sentence_count']} sentences\n"
        
        # Filler word metrics
        if 'text_filler_word_rate' in features:
            feature_text += f"- Filler words: {features['text_filler_word_rate']:.1f}% of words\n"
        
        if 'fillers_per_minute' in features:
            feature_text += f"- Filler frequency: {features['fillers_per_minute']:.1f} fillers per minute\n"
        
        # Vocabulary metrics
        if 'text_lexical_diversity' in features:
            feature_text += f"- Vocabulary diversity: {features['text_lexical_diversity']:.3f}\n"
        
        # Readability
        if 'text_flesch_kincaid_grade' in features:
            feature_text += f"- Reading level: grade {features['text_flesch_kincaid_grade']:.1f}\n"
        
        # Expressiveness
        if 'vocal_expressiveness' in features:
            feature_text += f"- Vocal expressiveness: {features['vocal_expressiveness']:.2f} (0-1 scale)\n"
        
        # Speech clarity
        if 'speech_clarity' in features:
            feature_text += f"- Speech clarity: {features['speech_clarity']:.2f} (0-1 scale)\n"
        
        return feature_text


class ClaudeTeacher(TeacherLLM):
    """Teacher model implementation using Anthropic's Claude."""
    
    def __init__(self, model_name: str = "claude-3-5-sonnet-20240620", api_key: Optional[str] = None):
        """
        Initialize the Claude-based teacher model.
        
        Args:
            model_name: Claude model name/version
            api_key: Anthropic API key (defaults to env var ANTHROPIC_API_KEY)
        """
        super().__init__(model_name)
        self.client = Anthropic(api_key=api_key)
    
    def generate_feedback(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate expert feedback using Claude.
        
        Args:
            features: Dictionary of presentation features
            
        Returns:
            Dictionary with structured feedback
        """
        logger.info(f"Generating feedback using {self.model_name}")
        
        # Format features for prompt
        feature_text = self._format_feature_input(features)
        
        # Create prompt
        prompt = f"""
You are an expert presentation coach with decades of experience helping speakers deliver compelling talks.
Analyze the following presentation metrics and provide detailed, actionable feedback.

{feature_text}

Provide a comprehensive analysis of this presentation with these components:

1. Numerical scores (1-10 scale) for:
   - Clarity of delivery
   - Engagement
   - Structure and pacing
   - Overall effectiveness

2. Three specific strengths with evidence from the metrics

3. Three concrete areas for improvement with actionable recommendations

4. A concise overall assessment (2-3 sentences)

Format your response as a valid JSON object with the following structure:
{{
  "scores": {{
    "clarity": <score>,
    "engagement": <score>,
    "structure": <score>,
    "overall": <score>
  }},
  "strengths": [
    "<strength 1>",
    "<strength 2>",
    "<strength 3>"
  ],
  "improvements": [
    "<improvement 1>",
    "<improvement 2>",
    "<improvement 3>"
  ],
  "assessment": "<overall assessment paragraph>"
}}

Ensure your feedback is data-driven, specific, and constructive.
"""
        
        # Call Claude API
        try:
            response = self.client.messages.create(
                model=self.model_name,
                max_tokens=1000,
                temperature=0.2,
                system="You are an expert presentation coach who provides specific, actionable feedback. Always respond with valid JSON.",
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            # Parse JSON response
            content = response.content[0].text
            feedback = json.loads(content)
            
            return feedback
            
        except Exception as e:
            logger.error(f"Error generating feedback with Claude: {str(e)}")
            # Return a basic structure in case of error
            return {
                "scores": {"clarity": 5, "engagement": 5, "structure": 5, "overall": 5},
                "strengths": ["Unable to analyze strengths due to API error"],
                "improvements": ["Unable to analyze improvements due to API error"],
                "assessment": f"Error generating feedback: {str(e)}"
            }


class GPT4Teacher(TeacherLLM):
    """Teacher model implementation using OpenAI's GPT-4."""
    
    def __init__(self, model_name: str = "gpt-4o", api_key: Optional[str] = None):
        """
        Initialize the GPT-4 based teacher model.
        
        Args:
            model_name: GPT model name/version
            api_key: OpenAI API key (defaults to env var OPENAI_API_KEY)
        """
        super().__init__(model_name)
        self.client = OpenAI(api_key=api_key)
    
    def generate_feedback(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate expert feedback using GPT-4.
        
        Args:
            features: Dictionary of presentation features
            
        Returns:
            Dictionary with structured feedback
        """
        logger.info(f"Generating feedback using {self.model_name}")
        
        # Format features for prompt
        feature_text = self._format_feature_input(features)
        
        # Create prompt
        prompt = f"""
You are an expert presentation coach with decades of experience helping speakers deliver compelling talks.
Analyze the following presentation metrics and provide detailed, actionable feedback.

{feature_text}

Provide a comprehensive analysis of this presentation with these components:

1. Numerical scores (1-10 scale) for:
   - Clarity of delivery
   - Engagement
   - Structure and pacing
   - Overall effectiveness

2. Three specific strengths with evidence from the metrics

3. Three concrete areas for improvement with actionable recommendations

4. A concise overall assessment (2-3 sentences)

Format your response as a valid JSON object with the following structure:
{{
  "scores": {{
    "clarity": <score>,
    "engagement": <score>,
    "structure": <score>,
    "overall": <score>
  }},
  "strengths": [
    "<strength 1>",
    "<strength 2>",
    "<strength 3>"
  ],
  "improvements": [
    "<improvement 1>",
    "<improvement 2>",
    "<improvement 3>"
  ],
  "assessment": "<overall assessment paragraph>"
}}

Ensure your feedback is data-driven, specific, and constructive.
"""
        
        # Call OpenAI API
        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                temperature=0.2,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": "You are an expert presentation coach who provides specific, actionable feedback. Always respond with valid JSON."},
                    {"role": "user", "content": prompt}
                ]
            )
            
            # Parse JSON response
            content = response.choices[0].message.content
            feedback = json.loads(content)
            
            return feedback
            
        except Exception as e:
            logger.error(f"Error generating feedback with GPT-4: {str(e)}")
            # Return a basic structure in case of error
            return {
                "scores": {"clarity": 5, "engagement": 5, "structure": 5, "overall": 5},
                "strengths": ["Unable to analyze strengths due to API error"],
                "improvements": ["Unable to analyze improvements due to API error"],
                "assessment": f"Error generating feedback: {str(e)}"
            }


class GemmaTeacher(TeacherLLM):
    """Teacher model implementation using Google's Gemma-7B."""
    
    def __init__(self, model_name: str = "models/gemma-7b-it", api_key: Optional[str] = None):
        """
        Initialize the Gemma-based teacher model.
        
        Args:
            model_name: Gemma model name/version
            api_key: Google API key (defaults to env var GOOGLE_API_KEY)
        """
        super().__init__(model_name)
        
        # Configure the Google Generative AI API
        if api_key is None:
            api_key = os.environ.get("GOOGLE_API_KEY")
            if not api_key:
                raise ValueError("GOOGLE_API_KEY environment variable not set")
        
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel(model_name)
    
    def generate_feedback(self, features: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate expert feedback using Gemma.
        
        Args:
            features: Dictionary of presentation features
            
        Returns:
            Dictionary with structured feedback
        """
        logger.info(f"Generating feedback using {self.model_name}")
        
        # Format features for prompt
        feature_text = self._format_feature_input(features)
        
        # Create prompt
        prompt = f"""
You are an expert presentation coach with decades of experience helping speakers deliver compelling talks.
Analyze the following presentation metrics and provide detailed, actionable feedback.

{feature_text}

Provide a comprehensive analysis of this presentation with these components:

1. Numerical scores (1-10 scale) for:
   - Clarity of delivery
   - Engagement
   - Structure and pacing
   - Overall effectiveness

2. Three specific strengths with evidence from the metrics

3. Three concrete areas for improvement with actionable recommendations

4. A concise overall assessment (2-3 sentences)

Format your response as a valid JSON object with the following structure:
{{
  "scores": {{
    "clarity": <score>,
    "engagement": <score>,
    "structure": <score>,
    "overall": <score>
  }},
  "strengths": [
    "<strength 1>",
    "<strength 2>",
    "<strength 3>"
  ],
  "improvements": [
    "<improvement 1>",
    "<improvement 2>",
    "<improvement 3>"
  ],
  "assessment": "<overall assessment paragraph>"
}}

Ensure your feedback is data-driven, specific, and constructive. Always respond in valid JSON format.
"""
        
        # Call Gemma API
        try:
            response = self.model.generate_content(
                prompt,
                generation_config=genai.GenerationConfig(
                    temperature=0.2,
                    max_output_tokens=1000,
                    response_mime_type="application/json"
                )
            )
            
            # Parse JSON response
            content = response.text
            feedback = json.loads(content)
            
            return feedback
            
        except Exception as e:
            logger.error(f"Error generating feedback with Gemma: {str(e)}")
            # Return a basic structure in case of error
            return {
                "scores": {"clarity": 5, "engagement": 5, "structure": 5, "overall": 5},
                "strengths": ["Unable to analyze strengths due to API error"],
                "improvements": ["Unable to analyze improvements due to API error"],
                "assessment": f"Error generating feedback: {str(e)}"
            }


def get_teacher_model(provider: str = "anthropic") -> TeacherLLM:
    """
    Get the appropriate teacher model based on provider.
    
    Args:
        provider: LLM provider to use ("anthropic", "openai", or "gemma")
        
    Returns:
        Teacher model instance
    """
    if provider.lower() == "anthropic":
        return ClaudeTeacher()
    elif provider.lower() == "openai":
        return GPT4Teacher()
    elif provider.lower() == "gemma":
        return GemmaTeacher()
    else:
        raise ValueError(f"Unsupported provider: {provider}. Use 'anthropic', 'openai', or 'gemma'.")


def generate_feedback_for_presentation(
    features_path: str,
    output_path: Optional[str] = None,
    provider: str = "anthropic"
) -> Dict[str, Any]:
    """
    Generate feedback for a presentation using the teacher model.
    
    Args:
        features_path: Path to presentation features JSON file
        output_path: Optional path to save feedback as JSON
        provider: LLM provider to use
        
    Returns:
        Dictionary with feedback
    """
    # Load features
    with open(features_path, 'r', encoding='utf-8') as f:
        features = json.load(f)
    
    # Get teacher model
    teacher = get_teacher_model(provider)
    
    # Generate feedback
    feedback = teacher.generate_feedback(features)
    
    # Save feedback if output path is provided
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(feedback, f, indent=2)
        logger.info(f"Saved feedback to {output_path}")
    
    return feedback


def batch_generate_feedback(
    feature_files: List[str],
    output_dir: str = "data/feedback",
    provider: str = "anthropic"
) -> List[Dict[str, Any]]:
    """
    Generate feedback for multiple presentations.
    
    Args:
        feature_files: List of paths to feature JSON files
        output_dir: Directory to save feedback files
        provider: LLM provider to use
        
    Returns:
        List of feedback dictionaries
    """
    os.makedirs(output_dir, exist_ok=True)
    results = []
    
    for i, feature_path in enumerate(feature_files):
        try:
            # Generate output filename
            filename = os.path.basename(feature_path).replace("_features.json", "_feedback.json")
            output_path = os.path.join(output_dir, filename)
            
            # Generate feedback
            feedback = generate_feedback_for_presentation(
                features_path=feature_path,
                output_path=output_path,
                provider=provider
            )
            
            # Store result
            results.append({
                'input_path': feature_path,
                'output_path': output_path,
                'feedback': feedback
            })
            
            logger.info(f"Generated feedback for presentation {i+1}/{len(feature_files)}")
            
            # Add a small delay to avoid rate limits
            if i < len(feature_files) - 1:
                time.sleep(1)
                
        except Exception as e:
            logger.error(f"Error generating feedback for {feature_path}: {str(e)}")
    
    return results


if __name__ == "__main__":
    # Example usage
    test_feature_file = "data/processed/sample_presentation_features.json"
    
    if os.path.exists(test_feature_file):
        feedback = generate_feedback_for_presentation(
            features_path=test_feature_file,
            output_path="data/feedback/sample_presentation_feedback.json"
        )
        
        print("Generated feedback:")
        print(json.dumps(feedback, indent=2))
    else:
        print(f"Test feature file not found: {test_feature_file}")
        print("Please process a presentation first to generate features.") 